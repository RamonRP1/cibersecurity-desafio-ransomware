# Projeto Prático: Descriptografia em Python

Este repositório contém um projeto prático desenvolvido no Kali Linux utilizando Python. O objetivo é explorar conceitos de segurança cibernética e manipulação de arquivos criptografados.

## 🛠 Funcionalidades
- Descriptografia de arquivos criptografados usando AES (CTR).
- Exclusão do arquivo criptografado.
- Criação de um novo arquivo com os dados restaurados.

## 🚀 Como executar o projeto
1. Certifique-se de ter o Python 3 instalado.
2. Instale a biblioteca necessária:
   ```bash
   pip install pyaes
   ```
3. Execute o programa:
   ```bash
   python3 decrypter.py
   ```

## 📁 Estrutura do Projeto
- `decrypter.py`: Código-fonte principal.
- `teste.txt.ransomwaretroll`: Exemplo de arquivo criptografado.

## 📝 Observações
- Use este projeto de forma ética e apenas em ambientes autorizados.
- Personalize a chave de criptografia (`key`) para fins educativos.

---

Desenvolvido como parte do Bootcamp DIO 🚀.
